# BasicChatRoom
A basic chatroom to practice Sockets and Threading

To start up:
Run server.py on server and make sure to port forward if going through the internet. 

Client:
Run Client.py and enter server IP/Hostname and then port.

Then start chatting. 


Do /help for some extra features like: /kick, /ban, /online. 

Please send any log files to me if Client or Server crashes! :) 
